import app from "./app";
import { logger } from "./lib/logger";
import { bootstrapControlAdmin } from "./control/bootstrap";
import { startControlWorker } from "./control/worker";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

app.listen(port, (err) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "Server listening");
  void bootstrapControlAdmin().then(()=>startControlWorker()).catch(()=>{
    logger.error("Conta inicial não provisionada; verifique a configuração segura. Nenhum privilégio existente foi alterado.");
    startControlWorker();
  });
});
